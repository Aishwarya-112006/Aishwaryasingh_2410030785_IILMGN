This folder contains dsa questions in python language  which  help help to enhance logical thinking and programming language concepts.
This contains topics like :
1}Arrays
